public class Main {
    public static void main(String[] args) {
        Task1.run();
        Task2.run();
        Task3.run();
        Task4.run();
        Task5.run();
        Task6.run();
        Task7.run();
    }
}