public class Task3 {
    public static void run() {
        String[] words = {"ala", "ma", "kota"};
        System.out.print("Zadanie 3: ");
        for (String word : words) {
            System.out.print(word.toUpperCase() + " ");
        }
        System.out.println();
    }
}
